extern "C" {

#include "ADF_interface.c"

}
